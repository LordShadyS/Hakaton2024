<?php
// Конфигурация базы данных
$db_file = 'users.db';

try {
    // Подключение к базе данных SQLite
    $db = new PDO("sqlite:$db_file");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Создание таблицы, если она не существует
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        level INTEGER NOT NULL CHECK(level >= 1 AND level <= 4)
    )");
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Проверка отправки формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $level = (int)$_POST['level'];

    // Валидация данных
    if (empty($username) || empty($password) || $level < 1 || $level > 4) {
        $error = "Все поля обязательны для заполнения и уровень должен быть от 1 до 4.";
    } else {
        try {
            // Хэширование пароля
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Вставка данных в базу данных
            $stmt = $db->prepare("INSERT INTO users (username, password, level) VALUES (:username, :password, :level)");
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':level', $level);

            if ($stmt->execute()) {
                $success = "Регистрация успешна!";
            } else {
                $error = "Ошибка при регистрации.";
            }
        } catch (PDOException $e) {
            $error = "Пользователь с таким логином уже существует.";
        }
    }
}
?>

<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="keywords" content="Site keywords here">
        <meta name="description" content="">
        <meta name='copyright' content=''>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Title -->
        <title>Математика</title>

        <!-- Favicon -->
        <link rel="icon" href="img/favicon.png">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Custom CSS -->
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <!-- Header Area -->
        <header class="header">
            <!-- Topbar -->
            <div class="topbar">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-5 col-12">
                            <!-- Contact -->
                            <ul class="top-link">
                                <li><a href="/index.php">Главная</a></li>
                                <li><a href="/subscribe.php">Подписка</a></li>
                            </ul>
                            <!-- End Contact -->
                        </div>
                        <div class="col-lg-6 col-md-7 col-12">
                            <!-- Top Contact -->
                            <ul class="top-contact">
                                <li><i class="fa fa-phone"></i>+7 xxx xx xxxx</li>
                                <li><i class="fa fa-envelope"></i><a href="mailto:email@email.com">email@email.com</a></li>
                            </ul>
                            <!-- End Top Contact -->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- End Header Area -->

        <!-- Registration Section -->
        <section class="register py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header text-center">
                                <h3>Регистрация</h3>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($error)): ?>
                                    <div class="alert alert-danger">
                                        <?php echo $error; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($success)): ?>
                                    <div class="alert alert-success">
                                        <?php echo $success; ?>
                                    </div>
                                <?php endif; ?>
                                <form method="post" action="">
                                    <div class="form-group">
                                        <label for="username">Имя:</label>
                                        <input type="text" id="username" name="username" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Пароль:</label>
                                        <input type="password" id="password" name="password" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="level">Выберите уровень:</label>
                                        <select id="level" name="level" class="form-control" required>
                                            <option value="1">Новичок</option>
                                            <option value="2">Средний</option>
                                            <option value="3">Профессионал</option>
                                            <option value="4">Специалист</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block">Зарегистрироваться</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Area -->
        <!-- End Footer Area -->

        <!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
        <!-- Bootstrap JS -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Main JS -->
        <script src="js/main.js"></script>
    </body>
</html>
